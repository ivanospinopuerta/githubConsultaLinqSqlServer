﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SubirArchivos
{
    public partial class SubirArchivo1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BotonSubirArchivo_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                string extensionArchivo = System.IO.Path.GetExtension(FileUpload1.FileName);
                extensionArchivo = extensionArchivo.ToLower();

                int tamañoFichero = FileUpload1.PostedFile.ContentLength;

                if (extensionArchivo == ".mp3" || extensionArchivo == ".mp4" && tamañoFichero <= 524288000)
                {
                    FileUpload1.SaveAs(Server.MapPath("~/ArchivosSubidosIvan/") + FileUpload1.FileName);

                    Etiqueta.Text = "Se subió el archivo";

                    string rutaFichero = "~/ArchivosSubidosIvan/" + FileUpload1.FileName;

                    rutaFichero = "<video width=700 Controls><Source src=" + rutaFichero + " type=video/mp4></video>";
                    Literal1.Text = rutaFichero;
                    
                }
            }
            else
            {
                Etiqueta.Text = "Debe seleccionar un archivo para subirlo!";
            }
        }
    }
}